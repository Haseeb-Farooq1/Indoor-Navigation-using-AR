using UnityEngine;
using ZXing;
using ZXing.QrCode;

namespace QRCodeShareMain
{
    public static class QRCodeShare
    {
        public static string ReadQRCodeImage(Texture2D qrCodeImage)
        {
            if (qrCodeImage == null)
            {
                Debug.LogError("Invalid Image for extraction!");
                return null;
            }

            // Create a reader with a custom luminance source
            var reader = new BarcodeReader();
            var result = reader.Decode(qrCodeImage.GetPixels32(), qrCodeImage.width, qrCodeImage.height);
            if (result != null)
            {
                return result.Text;
            }

            Debug.LogError("No Result Extracted from Image!");
            return null;
        }
        
        public static Texture2D CreateQRCodeImage(string content)
        {
            var writer = new BarcodeWriter
            {
                Format = BarcodeFormat.QR_CODE,
                Options = new QrCodeEncodingOptions
                {
                    Margin = 0
                }
            };
            Color32[] colors = writer.Write(content);
            int width = writer.Options.Width > 0 ? writer.Options.Width : 256;
            int height = writer.Options.Height > 0 ? writer.Options.Height : 256;
            
            // ✅ Corrected Texture2D Constructor
            Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            texture.SetPixels32(colors);
            texture.Apply();
            return texture;
        }
        
        public static Texture2D CreateQRCodeImage(string content, QRImageProperties properties)
        {
            int minSize = QRCodeMinimumSize(content).x;
            int shorterEdge = Mathf.Min(properties.Width, properties.Height);
            int targetSize = (Mathf.Max(properties.Width, properties.Width) / minSize + 1) * minSize;
            
            if (shorterEdge < minSize)
            {
                Debug.LogWarning("Width or height is smaller than minimum QR Code Size. Size Setting ignored. Fallback to Min Size QR Code.");
            }
            
            var writer = new BarcodeWriter
            {
                Format = BarcodeFormat.QR_CODE,
                Options = new QrCodeEncodingOptions
                {
                    Width = shorterEdge >= minSize ? targetSize : 0,
                    Height = shorterEdge >= minSize ? targetSize : 0,
                    Margin = 0
                }
            };
            
            Color32[] colors = writer.Write(content);
            int width = writer.Options.Width > 0 ? writer.Options.Width : minSize;
            int height = writer.Options.Height > 0 ? writer.Options.Height : minSize;

            // ✅ Corrected Texture2D Constructor
            Texture2D texture = new Texture2D(width, height, TextureFormat.RGBA32, false);
            texture.SetPixels32(colors);
            texture.Apply();
            
            // Resize QR Code if necessary
            if (shorterEdge >= minSize)
            {
                texture = ImageProcessing.ResizeTexture(texture, properties.Width, properties.Height);
            }

            Texture2D paddedTexture = ImageProcessing.AddPadding(texture, properties.TopMargin, properties.BottomMargin,
                properties.LeftMargin, properties.RightMargin, properties.PaddingColor);
            return paddedTexture;
        }

        public static Vector2Int QRCodeMinimumSize(string content)
        {
            Texture2D t = CreateQRCodeImage(content);
            return new Vector2Int(t.width, t.height);
        }
    }
}
